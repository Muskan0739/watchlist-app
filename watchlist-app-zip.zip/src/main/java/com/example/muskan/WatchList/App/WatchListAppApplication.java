package com.example.muskan.WatchList.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WatchListAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WatchListAppApplication.class, args);
	}

}
