package com.example.muskan.WatchList.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchListAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
